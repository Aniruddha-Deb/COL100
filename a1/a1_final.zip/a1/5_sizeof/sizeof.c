#include <stdio.h>
#include <stdbool.h>

int main() {

	printf("Size of int is %d bytes\n", sizeof(int));
	printf("Size of float is %d bytes\n", sizeof(float));
	printf("Size of bool is %d bytes\n", sizeof(bool));
	printf("Size of char is %d bytes\n", sizeof(char));
	printf("Size of double is %d bytes\n", sizeof(double));
	
	return 0;
}
